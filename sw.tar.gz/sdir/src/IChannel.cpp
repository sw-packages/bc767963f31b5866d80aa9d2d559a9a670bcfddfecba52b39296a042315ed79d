#include <postgres/internal/IChannel.h>

namespace postgres::internal {

IChannel::~IChannel() noexcept = default;

}  // namespace postgres::internal
